a = 1

def fun():
    global a
    a += 1
    print a
    global b
    b = 3

fun()
print a
print b
