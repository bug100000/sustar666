for (i,j) in [(1,2),(3,4),(5,6)]:
    print "i = %d,j = %d"%(i,j)

l = [x**2 for x in [1,2,3,4,5]]

print l
