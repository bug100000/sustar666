#coding=utf-8

def deco(fun):
    def func(*args,**kwargs):
        if args[0] != "毛裤":
            ret = fun(args[0])
            return ret + "毛裤"
        return args[0]
    return func

@deco
def fun(a):
    return a

#fun = deco(fun)

print fun("毛裤")
