def func():
    return 1,2,3,4

a,b,c,d = func()

print a,b,c,d
