#coding=utf-8
#print ("保存字符串格式")
print "保存字符串格式"
