class Protect(object):

    def __init__(self):
        self.job = "teacher"
        self.__name = "admin"


    def __python(self):
        print "teach python"

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self,name = "admin"):
        if 4 <= len(name) <= 8:
            self.__name = name
        else:
            pass


class Private(Protect):
    pass

t = Protect()

t.name = "zhangsan"
print t.name
#
# print t.job
#
# t.setName("li")
# print t.getName()
# print t.__name
# t.__python()

# t1 = Private()
#
# t1.setName("wugang")
# print t1.getName()
#print dir(t1)

#t1.__python()
