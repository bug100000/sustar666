a = input()
b = input()

c,d = input()
print a,b

print c,d
