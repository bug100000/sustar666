class A(object):
    attr = "test"


class B(A):
    pass

class C(B):
    pass

class D(object):
    pass

c = C()

print issubclass(C,A)

print isinstance(c,(A,B,C,D))

n = 1
print isinstance(n,int)

print "=================================="
a = A()
print hasattr(a,"attr")

print getattr(a,'attr','sorry')

setattr(a,'name','zhangsan')
print a.name

delattr(a,'name')
