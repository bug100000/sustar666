class FirstClass(object):

    name = "zhangsan"

    def fun(self):
        print "first class"

    class Meta(object):
        age = 15


first = FirstClass()

print first.name

first.fun()

meta = first.Meta()

print meta.age

# First = FirstClass
#
# print type(First)
#
# two = First()
#
# print two.name
