s = '''hello 
     world'''

print s
