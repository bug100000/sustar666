def outer():
    print ("outer....")
    a  = 10
    def inner():
        nonlocal a
        a += 1
        print (a)
        print ("inner....")
    inner()

outer()
#inner()
