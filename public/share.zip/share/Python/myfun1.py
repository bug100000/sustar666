def deco(arg):
    def _deco(fun):
        def __deco(a,b):
            print "before"
            ret = fun(a,b)
            print "after"
            return ret * arg
        return __deco
    return _deco

@deco(2)
def fun(a,b):
    return a + b

print fun(1,2)
