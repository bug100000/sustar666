#!/usr/bin/python


class Calculator(object):
    name = "luosifu"

    age = 88

class Talker(object):
    name = "liyong"

    sex = 'man'

class TalkCalculator(Calculator,Talker):
    pass


A = TalkCalculator()

print A.name
print A.sex

print TalkCalculator.__mro__
print TalkCalculator.mro()
