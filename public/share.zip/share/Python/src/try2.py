#!/usr/bin/python

def div(a,b):
    c = None
    try:
        c = a / b
    except ZeroDivisionError:
        print("zero can not be divsion")
    except TypeError:
        print("please input the right num")
    else:
        print("else......")
    finally:
        print("finally.....")
    return c

result = div(3,0)
print(result)

