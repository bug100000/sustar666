#!/usr/bin/python

class test:
    def __enter__(self):
        print("enter....")
#        return 1
    def __exit__(self,type,value,traceback):
        print("exit...")

with test() as Thing:
    print("doing something")
