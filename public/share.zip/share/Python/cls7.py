'''This is a doc two'''
class A(object):
    '''This is a class A document'''
    def __init__(self):
        print "__init__..............."
        self.dict = {}

    def __new__(cls):
        print "__new__..............."
        return super(A,cls).__new__(cls)

    def __del__(self):
        print "__del__................."

    def __call__(self,n):
        print "call..........",n


    def __getattr__(self,name):
        print 'You use getattr on attr %s'%name
        return

    def __setattr__(self,name,value):
        print "You use setattr"
        self.__dict__[name] = value

    def __delattr__(self,name):
        print "You use delattr"


    def __getitem__(self,key):
        return self.dict[key]

    def __setitem__(self,key,value):
        self.dict[key] = value

    def __len__(self):
        return len(self.dict)


a = A()

print "=================="
a['a'] = 1
print a['a']
print len(a)
print "===================="
a(1)
#del a
print a.__doc__
print a.__module__

a.value = 100
print a.value

del a.value
