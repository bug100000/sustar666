if condition:
  pass
  pass
  pass
