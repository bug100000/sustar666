def func(a):
    a[0] = 10
    print a


l = [1,2,3,4]

l1 = l[:]

func(l1)

print l
