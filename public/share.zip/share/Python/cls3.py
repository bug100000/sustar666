#coding=utf-8

class Car(object):
    def __init__(self,name):
        self.name = name

    door = 4
    def run(self):
        print "跑....."

class Dazhong(Car):
    pass

class Badao(Car):
    site = 7

class Bense(Car):
    def run(self):
        print "跑得快"

b = Badao("fengtian")
print b.door
print b.site

ben = Bense("meisaidesi")
ben.run()
