#coding=utf-8
class Person(object):
    age = 12

    def __init__(self,name):
        self.name = name

    def change_age(self,num):
        self.age = self.age + num




a = Person("小明")
b = Person("小丽")

a.change_age(3)
print a.age
print a.name

b.change_age(-1)
print b.age
print b.name

#1
def fun(self):
    print self
    print "add function"

Person.fun = fun

b.fun()

#2
b.f = fun

print b.f
b.f(1)

#3
import new
b.f = new.instancemethod(fun,b,Person)
b.f()
