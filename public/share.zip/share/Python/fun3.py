#coding=utf-8

#python3

def func2(a,*b,c):
    print (a,b,c)

func2(1,2,3,4,c = 5)
