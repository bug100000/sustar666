#coding=utf-8

class Person(object):
    sex = "man"
    age = 18

    def fun(self):
        print "跑得快"

print "+++++++++++++++++++++"
Person.age = 19
print Person.sex
print Person.age

a = Person()

a.name = "孙悟空"
a.age = 20
print a.sex
print a.age
print a.name

b = Person()

print b.sex
print b.age
#print b.name


#print Person.name
