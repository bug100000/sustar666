with open('file.txt','w+') as fd:
#    print >>fd,"hello world"
    print ("hello world",file = fd)
