
def inspect(arg):
    def deco(fun):
        def wrapper(name):
            ret = fun(name)
            if 4 <= len(ret) <=8:
                return ret
            else:
                return arg
        return wrapper
    return deco



@inspect("admin")
def reg(name):
    return name

name = raw_input()

print reg(name)
