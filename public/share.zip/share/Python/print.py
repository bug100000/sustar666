print ("a = %(a)d,b = %(b)d"%({'a':1,'b':2}),end = '')

print ("asdfas")
