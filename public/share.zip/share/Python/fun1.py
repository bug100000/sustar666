def func(a,b):
    print "a:",a
    print "b:",b


func(1,2)
print "=========================="
func(b = 2,a = 3)
print "========================="

l = [2,3]
func(*l)
print "=============================="

d = {'a':1,'b':2 }
func(**d)
