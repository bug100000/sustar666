def func(a,b):
    print "a:",a
    print "b:",b

func(1,2)


def func1(a,b = 100):
    print "a:",a
    print "b:",b

func1(1)

def func2(a,b = 100,*c):
    print a,b,c

func2(1,2,3,4,5)

def func3(a,b = 100,*c,**d):
    print a,b,c,d

func3(1,2,4,'a','abc',[1,2,3],c = 6)
